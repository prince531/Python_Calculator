import math as m
from tkinter import *
from tkinter.messagebox import *

# some useful variables
font = ("Arial", 16, "bold")

# --- History storage ---
history = []


# important functions
def clear_input():
    ex = textField.get()
    ex = ex[0 : len(ex) - 1]
    textField.delete(0, END)
    textField.insert(0, ex)


def all_clear():
    textField.delete(0, END)


def add_history_item(expr, result):
    """Add a human-readable entry to history list."""
    history.append(f"{expr} = {result}")


def click_btn_function(event):
    b = event.widget
    text = b["text"]

    if text == "x":
        textField.insert(END, "*")
        return

    if text == "%":
        textField.insert(END, "/100")
        return

    if text == "=":
        try:
            ex = textField.get()
            # allow '^' as power (user might use scientific pow button)
            safe_ex = ex.replace("^", "**")
            answer = eval(safe_ex)
            textField.delete(0, END)
            textField.insert(0, answer)
            add_history_item(ex, answer)
        except Exception as e:
            print("Error...", e)
            showerror("Error...", e)
            textField.delete(0, END)
            textField.insert(0, "Error")
        return

    textField.insert(END, text)


# --- Create a window ---
window = Tk()
window.config(bg="#88dfe4")
window.geometry("330x485")  # Basic Calculator
window.title("Calculator")

# Heading Label (changed to Basic Calculator)
heading = Label(
    window,
    text="Basic Calculator",
    font=("Arial", 24, "bold"),
    bg="#88dfe4",
    fg="black",
    pady=10,
    underline=0,
)
heading.pack(fill=X)

# Footer Label (unchanged)
footer = Label(
    window,
    text="Design By Prince Kumar",
    font=("Brush Script MT", 12, "underline"),
    anchor=E,
    padx=10,
    bg="#88dfe4",
    fg="black",
)
footer.pack(fill=X, side=BOTTOM)

# Text Field
textField = Entry(
    window,
    font=("Arial", 24, "bold"),
    justify=RIGHT,
    relief="ridge",
    bd=7,
    bg="#a6d3ba",
    fg="black",
)
textField.pack(fill=X, pady=10, padx=10, ipady=15)

# -------- HISTORY ICON (just below textfield, thoda left) --------
historyFrame = Frame(window, background="#88dfe4")
historyFrame.pack(side=TOP, pady=5, fill=X)

hist_canvas = Canvas(
    historyFrame, width=40, height=40, highlightthickness=0, bd=0, bg="#88dfe4"
)
hist_canvas.pack(side=LEFT, padx=40)

ICON_NORMAL = "#000000"
ICON_HOVER = "orange"
RIPPLE_COLOR = "#AAAAAA"


def draw_history_icon(color):
    """Draw history/clock icon on the small canvas with given color."""
    hist_canvas.delete("all")
    # Outer arc (history arrow curve)
    hist_canvas.create_arc(
        6, 6, 34, 34, start=160, extent=260, style="arc", outline=color, width=2
    )
    # Arrow head
    hist_canvas.create_polygon(8, 12, 8, 20, 14, 14, fill=color, outline=color)
    # Inner small clock circle
    hist_canvas.create_oval(14, 14, 26, 26, outline=color, width=2)
    # Clock hands
    hist_canvas.create_line(20, 20, 20, 15, fill=color, width=2)
    hist_canvas.create_line(20, 20, 24, 20, fill=color, width=2)


def ripple_effect():
    """Simple ripple animation on click."""
    x_center, y_center = 20, 20
    max_radius = 18
    steps = 6
    oval = hist_canvas.create_oval(
        x_center, y_center, x_center, y_center, outline=RIPPLE_COLOR, width=2
    )

    def expand(step):
        if step > steps:
            hist_canvas.delete(oval)
            return
        r = (max_radius / steps) * step
        hist_canvas.coords(oval, x_center - r, y_center - r, x_center + r, y_center + r)
        hist_canvas.after(30, lambda: expand(step + 1))

    expand(0)


def show_history():
    """Open a history window showing past calculations; double-click to load expression."""
    if not history:
        showinfo("History", "No history yet!")
        return

    hist_win = Toplevel(window)
    hist_win.title("Calculation History")
    hist_win.config(bg="#A7BEA8")
    hist_win.geometry("400x400")

    listbox = Listbox(hist_win, font=("consolas", 14))
    listbox.pack(side=LEFT, fill=BOTH, expand=True, padx=5, pady=5)

    scrollbar = Scrollbar(hist_win, command=listbox.yview)
    scrollbar.pack(side=RIGHT, fill=Y)
    listbox.config(yscrollcommand=scrollbar.set)

    for item in history:
        listbox.insert(END, item)

    def on_history_double(event):
        sel = listbox.curselection()
        if not sel:
            return
        item = listbox.get(sel[0])
        expr = item.split("=")[0].strip()
        textField.delete(0, END)
        textField.insert(0, expr)

    listbox.bind("<Double-Button-1>", on_history_double)


def on_icon_enter(event):
    draw_history_icon(ICON_HOVER)


def on_icon_leave(event):
    draw_history_icon(ICON_NORMAL)


def on_icon_click(event):
    ripple_effect()
    show_history()


# initial draw and bindings
draw_history_icon(ICON_NORMAL)
hist_canvas.configure(cursor="hand2")
hist_canvas.bind("<Enter>", on_icon_enter)
hist_canvas.bind("<Leave>", on_icon_leave)
hist_canvas.bind("<Button-1>", on_icon_click)

# Buttons frame (colors preserved exactly)
buttonFrame = Frame(window)
buttonFrame.pack(side=TOP)
buttonFrame.config(bg="#88dfe4")

# Adding buttons 1..9
temp = 1
for i in range(0, 3):
    for j in range(0, 3):
        btn = Button(
            buttonFrame,
            text=str(temp),
            font=font,
            width=5,
            height=1,
            relief="ridge",
            bg="#abe8ec",
            activebackground="#06e8f8",
            activeforeground="White",
        )
        btn.grid(row=i, column=j, padx=3, pady=3)
        temp = temp + 1
        btn.bind("<Button-1>", click_btn_function)

# zero, dot, equal
zeroBtn = Button(
    buttonFrame,
    text="0",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    bg="#abe8ec",
    activebackground="#06e8f8",
    activeforeground="White",
)
zeroBtn.grid(row=3, column=0, padx=3, pady=3)

dotBtn = Button(
    buttonFrame,
    text=".",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    bg="#abe8ec",
    activebackground="#06e8f8",
    activeforeground="White",
)
dotBtn.grid(row=3, column=1, padx=3, pady=3)

equalBtn = Button(
    buttonFrame,
    text="=",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    bg="#86afc0",
    activebackground="#3f747e",
    activeforeground="White",
)
equalBtn.grid(row=3, column=2, padx=3, pady=3)

plusBtn = Button(
    buttonFrame,
    text="+",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    bg="#86afc0",
    activebackground="#3f747e",
    activeforeground="White",
)
plusBtn.grid(row=0, column=3, padx=3, pady=3)

minusBtn = Button(
    buttonFrame,
    text="-",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    bg="#86afc0",
    activebackground="#3f747e",
    activeforeground="White",
)
minusBtn.grid(row=1, column=3, padx=3, pady=3)

multiplyBtn = Button(
    buttonFrame,
    text="x",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    bg="#86afc0",
    activebackground="#3f747e",
    activeforeground="White",
)
multiplyBtn.grid(row=2, column=3, padx=3, pady=3)

divideBtn = Button(
    buttonFrame,
    text="/",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    bg="#86afc0",
    activebackground="#3f747e",
    activeforeground="White",
)
divideBtn.grid(row=3, column=3, padx=3, pady=3)

clearBtn = Button(
    buttonFrame,
    text="⌫",
    font=font,
    width=5,
    height=1,
    command=clear_input,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
clearBtn.grid(row=4, column=0, padx=3, pady=3)

percentBtn = Button(
    buttonFrame,
    text="%",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    bg="#86afc0",
    activebackground="#3f747e",
    activeforeground="White",
)
percentBtn.grid(row=4, column=1, padx=3, pady=3)

allClearBtn = Button(
    buttonFrame,
    text="AC",
    font=font,
    border=5,
    width=11,
    height=1,
    command=all_clear,
    relief="ridge",
    activebackground="Red",
    activeforeground="White",
    bg="#F02704",
)
allClearBtn.grid(row=4, column=2, columnspan=2, padx=3, pady=3)

# Binding all buttons with functions
zeroBtn.bind("<Button-1>", click_btn_function)
dotBtn.bind("<Button-1>", click_btn_function)
equalBtn.bind("<Button-1>", click_btn_function)
plusBtn.bind("<Button-1>", click_btn_function)
minusBtn.bind("<Button-1>", click_btn_function)
multiplyBtn.bind("<Button-1>", click_btn_function)
divideBtn.bind("<Button-1>", click_btn_function)
percentBtn.bind("<Button-1>", click_btn_function)

# Scientific Calculator Frame (colors preserved)
scientificCalculatorFrame = Frame(window)
scientificCalculatorFrame.config(bg="#ffd001")

sqrtBtn = Button(
    scientificCalculatorFrame,
    text="√",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
sqrtBtn.grid(row=0, column=0, padx=3, pady=3)

powBtn = Button(
    scientificCalculatorFrame,
    text="^",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
powBtn.grid(row=0, column=1, padx=3, pady=3)

logBtn = Button(
    scientificCalculatorFrame,
    text="log",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
logBtn.grid(row=0, column=2, padx=3, pady=3)

sinBtn = Button(
    scientificCalculatorFrame,
    text="sin",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
sinBtn.grid(row=0, column=3, padx=3, pady=3)

cosBtn = Button(
    scientificCalculatorFrame,
    text="cos",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
cosBtn.grid(row=1, column=0, padx=3, pady=3)

tanBtn = Button(
    scientificCalculatorFrame,
    text="tan",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
tanBtn.grid(row=1, column=1, padx=3, pady=3)

piBtn = Button(
    scientificCalculatorFrame,
    text="π",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
piBtn.grid(row=1, column=2, padx=3, pady=3)

factBtn = Button(
    scientificCalculatorFrame,
    text="x!",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
factBtn.grid(row=1, column=3, padx=3, pady=3)

radianBtn = Button(
    scientificCalculatorFrame,
    text="Radc",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
radianBtn.grid(row=2, column=0, padx=3, pady=3)

degBtn = Button(
    scientificCalculatorFrame,
    text="Deg°",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
degBtn.grid(row=2, column=1, padx=3, pady=3)

inBtn = Button(
    scientificCalculatorFrame,
    text="In",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
inBtn.grid(row=2, column=2, padx=3, pady=3)

eulerBtn = Button(
    scientificCalculatorFrame,
    text="e",
    font=font,
    width=5,
    height=1,
    relief="ridge",
    activebackground="Orange",
    activeforeground="White",
    bg="#FCB51D",
)
eulerBtn.grid(row=2, column=3, padx=3, pady=3)

normalcalc = True


# Scientific Calculator button functions
def calculator_sc(event):
    btn = event.widget
    text = btn["text"]
    ex = textField.get()
    answer = ""
    if text == "√":
        try:
            answer = m.sqrt(float(ex))
        except Exception as e:
            showerror("Error", "Invalid input for sqrt")
            answer = "Error"

    elif text == "^":
        # keep same behaviour as original (pow with itself) but it's odd; preserve as requested
        try:
            answer = str(m.pow(float(ex), float(ex)))
        except Exception as e:
            showerror("Error", "Invalid input for pow")
            answer = "Error"

    elif text == "log":
        try:
            answer = str(m.log10(float(ex)))
        except ValueError:
            showerror("Error", "Input must be greater than 0 for log")
            answer = "Error"

    elif text == "sin":
        try:
            answer = str(m.sin(m.radians(float(ex))))
        except Exception:
            showerror("Error", "Input must be a number for sin")
            answer = "Error"

    elif text == "cos":
        try:
            answer = str(m.cos(m.radians(float(ex))))
        except Exception:
            showerror("Error", "Input must be a number for cos")
            answer = "Error"

    elif text == "tan":
        try:
            answer = str(m.tan(m.radians(float(ex))))
        except Exception:
            showerror("Error", "Input must be a number for tan")
            answer = "Error"

    elif text == "π":
        answer = str(m.pi)

    elif text == "x!":
        try:
            answer = str(m.factorial(int(ex)))
        except Exception:
            showerror("Error", "Input must be a non-negative integer for factorial")
            answer = "Error"

    elif text == "Radc":
        try:
            answer = str(m.radians(float(ex)))
        except Exception:
            showerror("Error", "Input must be a number for radians")
            answer = "Error"

    elif text == "Deg°":
        try:
            answer = str(m.degrees(float(ex)))
        except Exception:
            showerror("Error", "Input must be a number for degrees")
            answer = "Error"

    elif text == "In":
        try:
            answer = str(m.log(float(ex)))
        except ValueError:
            showerror("Error", "Input must be greater than 0 for ln")
            answer = "Error"

    elif text == "e":
        answer = str(m.e)

    else:
        answer = "Error"

    # Insert answer and save to history (use visible expr -> result)
    # For scientific ops, we record a readable expr
    expr_for_history = f"{text}({ex})" if text not in ["π", "e"] else text
    textField.delete(0, END)
    textField.insert(0, answer)
    add_history_item(expr_for_history, answer)


# Bind scientific buttons
sqrtBtn.bind("<Button-1>", calculator_sc)
powBtn.bind("<Button-1>", calculator_sc)
radianBtn.bind("<Button-1>", calculator_sc)
degBtn.bind("<Button-1>", calculator_sc)
logBtn.bind("<Button-1>", calculator_sc)
sinBtn.bind("<Button-1>", calculator_sc)
cosBtn.bind("<Button-1>", calculator_sc)
tanBtn.bind("<Button-1>", calculator_sc)
piBtn.bind("<Button-1>", calculator_sc)
factBtn.bind("<Button-1>", calculator_sc)
inBtn.bind("<Button-1>", calculator_sc)
eulerBtn.bind("<Button-1>", calculator_sc)


def scientific_calculator_click():
    global normalcalc
    if normalcalc:
        # scientific calculator
        buttonFrame.pack_forget()
        scientificCalculatorFrame.pack(side=TOP)
        buttonFrame.pack(side=TOP)
        window.geometry("350x640")  # Advanced Calculator
        heading.config(text="Scientific Calculator")
        normalcalc = False
    else:
        # normal calculator
        scientificCalculatorFrame.pack_forget()
        window.geometry("330x485")  # Basic Calculator
        buttonFrame.pack(side=TOP)
        heading.config(text="Basic Calculator")
        normalcalc = True


# Menu Bar (mode checkbutton)
menubar = Menu(window)
mode = Menu(menubar, font=font, tearoff=0, bg="#4AECF1")
mode.add_checkbutton(label="Scientific Calculator", command=scientific_calculator_click)
menubar.add_cascade(label="Mode", menu=mode)
window.config(menu=menubar)

# Start mainloop
window.mainloop()